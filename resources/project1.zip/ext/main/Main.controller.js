sap.ui.define(["sap/fe/core/PageController"],function(e){"use strict";return e.extend("project1.ext.main.Main",{})});
//# sourceMappingURL=Main.controller.js.map